package com.app.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dao.EmployeeRepository;
import com.app.pojos.Employee;

@Service
@Transactional
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	private EmployeeRepository empRepo;

	@Override
	public List<Employee> getAllEmpDetails() {
		return empRepo.findAll();
	}

	@Override
	public Employee savEmployeeDetails(Employee emp) {
		return empRepo.save(emp);
	}

	@Override
	public String deleteEmployeeDetails(int id) {

		String msg = "Employee deletion is failed...";

		if (empRepo.existsById(id)) {
			empRepo.deleteById(id);
			msg = "Employee deleted successfully with id: " + id;
		}

		return msg;
	}

	@Override
	public Employee getEmployeeDetailsById(int id) {

		return empRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Invalid employee id"+id));
	}

	@Override
	public Employee updateEmployeeDetalis(Employee emp) {
		
		return empRepo.save(emp);
	}
	
	

}
