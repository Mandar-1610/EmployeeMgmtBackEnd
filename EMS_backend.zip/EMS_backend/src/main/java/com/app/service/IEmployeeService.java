package com.app.service;

import java.util.List;

import com.app.pojos.Employee;

public interface IEmployeeService {
	//get all employees
	List<Employee> getAllEmpDetails();
	
	//save new emps details
	Employee savEmployeeDetails(Employee emp);
	
	//delete employee details
	String deleteEmployeeDetails(int id);
	
	//get employee details by specified id
	Employee getEmployeeDetailsById(int id);
	
	//update employee details
	Employee updateEmployeeDetalis(Employee emp);
}
