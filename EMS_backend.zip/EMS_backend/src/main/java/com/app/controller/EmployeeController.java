package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.Employee;
import com.app.service.IEmployeeService;

@RestController
@RequestMapping("/api/employees")
@CrossOrigin
public class EmployeeController {

	@Autowired
	private IEmployeeService empService;

	public EmployeeController() {
		System.out.println("inside constructor of class: " + getClass());
	}

	// req handling method for getting all the employees
	@GetMapping
	public ResponseEntity<?> listAllEmps() {
		System.out.println("inside listAllEmps() method of class: " + getClass());
		List<Employee> list = empService.getAllEmpDetails();
		if(list.isEmpty())
		{
			return new ResponseEntity<>("Employee lis is empty", HttpStatus.NO_CONTENT);
		}
		else {
			return new ResponseEntity<>(list, HttpStatus.OK);
		}
	}

	// req handing method for adding new employee
	@PostMapping
	public Employee saveEmployeeDetails(@RequestBody Employee emp) {
		System.out.println("inside saveEmployeeDetails() of class: " + getClass());
		return empService.savEmployeeDetails(emp);
	}
	
	//req handling foe deleting employee
	@DeleteMapping("/{id}")
	public String deleteEmployeeDetails(@PathVariable int id)
	{
		System.out.println("Inside deleteEmployeeDetails() method of class: "+getClass());
		return empService.deleteEmployeeDetails(id);
	}
	
	//req handling method for specific emp dels
	@GetMapping("/{id}")
	public Employee getDetails(@PathVariable int id)
	{
		System.out.println("inside getDetails() method of class: "+getClass());
		return empService.getEmployeeDetailsById(id);
	}
	
	//req handling for updating exsting resource
	@PutMapping
	public Employee updateEmployee(@RequestBody Employee emp) {
		return empService.updateEmployeeDetalis(emp);
	}
}
